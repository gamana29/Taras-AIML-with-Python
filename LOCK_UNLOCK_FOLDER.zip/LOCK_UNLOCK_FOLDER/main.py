import cv2
import os

# Paths
locked_folder = "locked_folder"
unlocked_folder = "unlocked_folder"

# Load Haar cascade
face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

# Start webcam
cap = cv2.VideoCapture(0)
folder_unlocked = False

print("Scanning face... Press ESC to exit")

while True:
    ret, frame = cap.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

    if len(faces) > 0:
        if not folder_unlocked:
            print("Face detected! Unlocking folder... ✅")
            if os.path.exists(locked_folder):
                os.rename(locked_folder, unlocked_folder)
            folder_unlocked = True
    else:
        if folder_unlocked:
            print("No face detected. Locking folder... 🔒")
            if os.path.exists(unlocked_folder):
                os.rename(unlocked_folder, locked_folder)
            folder_unlocked = False

    cv2.imshow("Camera", frame)

    if cv2.waitKey(1) == 27:
        # On exit, make sure folder is locked
        if folder_unlocked and os.path.exists(unlocked_folder):
            os.rename(unlocked_folder, locked_folder)
        print("Exiting...")
        break

cap.release()
cv2.destroyAllWindows()
