import os
import xml.etree.ElementTree as ET
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import time

# Folder and file
gps_folder = r"C:\Users\Gamana\OneDrive\Documents\Python AIML\final_project\Gpslogger"
file_path = os.path.join(gps_folder, "20260327-013213.gpx")

class GPXHandler(FileSystemEventHandler):
    def __init__(self, file_path):
        self.file_path = file_path
        self.last_lat, self.last_lon = None, None

    def on_modified(self, event):
        if event.src_path == self.file_path:
            try:
                tree = ET.parse(self.file_path)
                root = tree.getroot()
            except ET.ParseError:
                print("Error reading GPX file.")
                return

            # Detect namespace automatically
            ns = {}
            if root.tag.startswith("{"):
                ns_uri = root.tag.split("}")[0].strip("{")
                ns = {'gpx': ns_uri}
            else:
                ns = {'gpx': 'http://www.topografix.com/GPX/1/1'}

            points = root.findall(".//gpx:trkpt", ns)
            if points:
                last = points[-1]
                lat = last.get("lat")
                lon = last.get("lon")

                if (lat, lon) != (self.last_lat, self.last_lon):
                    print(lat, lon)
                    self.last_lat, self.last_lon = lat, lon

if __name__ == "__main__":
    print("Real-time tracking started...")
    if not os.path.exists(file_path):
        print("GPX file not found!")
        exit(1)

    event_handler = GPXHandler(file_path)
    observer = Observer()
    observer.schedule(event_handler, path=gps_folder, recursive=False)
    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
