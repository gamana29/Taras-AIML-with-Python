import firebase_admin
from firebase_admin import credentials, db
import time

cred = credentials.Certificate("location-predictor-a6864-firebase-adminsdk-fbsvc-4fcaee9322.json")

firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://location-predictor-a6864-default-rtdb.asia-southeast1.firebasedatabase.app/'
})

ref = db.reference('location')

print("Tracking started...")

while True:
    data = ref.get()
    
    if data:
        lat = data.get("lat")
        lon = data.get("lon")
        print("Live Location:", lat, lon)

    time.sleep(2)
