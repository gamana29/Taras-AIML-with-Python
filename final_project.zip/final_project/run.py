import os
import xml.etree.ElementTree as ET
import time

print("Tracking started...")

last_lat, last_lon = None, None

# Folder containing the GPX file
gps_folder = r"C:\Users\Gamana\OneDrive\Documents\Python AIML\final_project\Gpslogger"
file_path = os.path.join(gps_folder, "20260327-013213.gpx")

while True:
    if not os.path.exists(file_path):
        print("GPX file not found. Waiting...")
        time.sleep(5)
        continue

    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
    except ET.ParseError:
        print(f"Error reading {file_path}. Skipping...")
        time.sleep(5)
        continue

    # Detect namespace automatically
    ns = {}
    if root.tag.startswith("{"):
        ns_uri = root.tag.split("}")[0].strip("{")
        ns = {'gpx': ns_uri}
    else:
        ns = {'gpx': 'http://www.topografix.com/GPX/1/1'}

    points = root.findall(".//gpx:trkpt", ns)

    if points:
        last = points[-1]
        lat = last.get("lat")
        lon = last.get("lon")

        if (lat, lon) != (last_lat, last_lon):
            print("Live Location:", lat, lon)
            last_lat, last_lon = lat, lon

    time.sleep(1)
