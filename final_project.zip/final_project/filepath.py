import os

file_path = r"C:\Users\Gamana\OneDrive\Documents\Python AIML\final_project\GPX\Gpslogger.gpx"
print(os.path.exists(file_path))
