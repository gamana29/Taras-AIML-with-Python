import xml.etree.ElementTree as ET
import pandas as pd

tree = ET.parse("20260326-195836 - Home.kml")
root = tree.getroot()

ns = {'kml': 'http://www.opengis.net/kml/2.2'}

data = []

for coord in root.findall(".//kml:coordinates", ns):
    coords = coord.text.strip().split()
    for c in coords:
        lon, lat, *_ = c.split(',')
        data.append([float(lat), float(lon), "home"])  # added label

df = pd.DataFrame(data, columns=["Latitude", "Longitude", "Label"])
df.to_csv("dataset/gps_data.csv", index=False)

print(df)
