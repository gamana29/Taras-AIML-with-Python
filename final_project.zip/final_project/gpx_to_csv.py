import xml.etree.ElementTree as ET
import pandas as pd

tree = ET.parse("20260326-195836 - Home.gpx")
root = tree.getroot()

# 👉 Correct namespace (THIS is the fix)
ns = "{http://www.topografix.com/GPX/1/0}"

data = []

for pt in root.findall(".//" + ns + "trkpt"):
    lat = pt.attrib['lat']
    lon = pt.attrib['lon']
    
    time_elem = pt.find(ns + "time")
    time = time_elem.text if time_elem is not None else None

    data.append([float(lat), float(lon), time, "home"])

df = pd.DataFrame(data, columns=["Latitude", "Longitude", "Time", "Label"])
df.to_csv("dataset/gps_data_gpx.csv", index=False)

print(df)
