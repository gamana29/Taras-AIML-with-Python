import pywhatkit
pywhatkit.sendwhatmsg("+917382444567","HAPPY BIRTHDAY",13,36)
