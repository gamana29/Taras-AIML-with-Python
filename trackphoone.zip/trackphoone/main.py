<<<<<<< HEAD
import pandas as pd

# GPS data
data = {
    "lat": [17.3850, 17.3855, 17.3860, 17.3865, 17.3870, 17.3875, 17.3880, 17.3885, 17.3890, 17.3895, 17.3900, 17.3905, 17.3910, 17.3915, 17.3920],
    "lon": [78.4867, 78.4870, 78.4875, 78.4880, 78.4885, 78.4890, 78.4895, 78.4900, 78.4905, 78.4910, 78.4915, 78.4920, 78.4925, 78.4930, 78.4935],
    "time": list(range(1,16))
}

# Create DataFrame
df = pd.DataFrame(data)

# Save to CSV
df.to_csv("gps_data.csv", index=False)

print("gps_data.csv has been created!")
=======
import imutils #Resize
import cv2
import time
redLower = (35, 52 , 74)
redUpper = (179, 247, 169)

camera=cv2.VideoCapture(0) #Cam Ini
time.sleep(3)
while True:

        (grabbed, frame) = camera.read() #Read the Frame
        print(grabbed)

        frame = imutils.resize(frame, width=1000) #resize
        blurred = cv2.GaussianBlur(frame, (11, 11), 0)
        hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV) 

        mask = cv2.inRange(hsv, redLower, redUpper) #Mask the blue colour
        mask = cv2.erode(mask, None, iterations=2)
        mask = cv2.dilate(mask, None, iterations=2)


        cnts = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL,
                cv2.CHAIN_APPROX_SIMPLE)[-2]
        center = None
        if len(cnts) > 0:
                c = max(cnts, key=cv2.contourArea)
                ((x, y), radius) = cv2.minEnclosingCircle(c)
                M = cv2.moments(c)
                center = (int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"]))
                if radius > 10:
                        cv2.circle(frame, (int(x), int(y)), int(radius),
                                (0, 255, 255), 2)
                        cv2.circle(frame, center, 5, (0, 0, 255), -1)
                        #print(center,radius)
                        if radius > 250:
                                print("stop")
                        else:
                                if(center[0]<150):
                                        print("Right")
                                elif(center[0]>450):
                                        print("Left")
                                elif(radius<250):
                                        print("Front")
                                else:
                                        print("Stop")
        cv2.imshow("Frame", frame)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
                break

camera.release()
cv2.destroyAllWindows()
>>>>>>> 2a270580ab06fcfc47bb54b21a7b6844f2a91508
