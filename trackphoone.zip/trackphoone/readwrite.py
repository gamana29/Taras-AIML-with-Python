import cv2
img = cv2.imread("IMG_20240524_131729.jpg")
cv2.imshow('show',img)
cv2.imwrite('photo.jpeg',img)
cv2.waitKey(10000)
cv2.destroyAllWindows()
