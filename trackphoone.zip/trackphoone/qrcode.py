import pyqrcode

url = "https://youtu.be/j7Red24s2cA?si=qHP6Bk4_m_6Gwem6"
k = pyqrcode.create(url, encoding='utf-8')
k.svg("video.svg", scale=10)
