import yt_dlp

url = "https://youtu.be/ObfJ9OYME-s?si=yTg40Ywky9kLXyD7"

ydl_opts = {
    'outtmpl': 'C:/Users/Gamana/Downloads/%(title)s.%(ext)s',
    'format': 'best',  
}

with yt_dlp.YoutubeDL(ydl_opts) as ydl:
    ydl.download([url])
