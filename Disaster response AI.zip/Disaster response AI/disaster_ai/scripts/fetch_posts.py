import praw
import pandas as pd
from dotenv import load_dotenv
import os
import logging
from datetime import datetime

load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def fetch_posts():
    """Fetch disaster-related Reddit posts using PRAW (free API)"""
    try:
        # Reddit API credentials (create script app at reddit.com/prefs/apps)
        client_id = os.getenv('REDDIT_CLIENT_ID')
        client_secret = os.getenv('REDDIT_CLIENT_SECRET')
        user_agent = os.getenv('REDDIT_USER_AGENT', 'DisasterResponseAI/1.0')

        if not client_id or not client_secret:
            logger.warning("Reddit API credentials missing in .env. Skipping post fetch. Get free keys: reddit.com/prefs/apps")
            return

        # Initialize Reddit client
        reddit = praw.Reddit(
            client_id=client_id,
            client_secret=client_secret,
            user_agent=user_agent
        )

        # Disaster subreddits and keywords
        subreddits = ['disaster', 'earthquakes', 'hurricane', 'floods', 'wildfires', 'emergencymanagement']
        keywords = [
            "flood OR flooding OR flashflood",
            "earthquake OR quake OR seismic",
            "wildfire OR forestfire OR bushfire",
            "hurricane OR typhoon OR cyclone",
            "tornado OR twister",
            "tsunami",
            "disaster OR emergency OR evacuation OR rescue"
        ]

        all_posts = []

        for subreddit_name in subreddits:
            try:
                subreddit = reddit.subreddit(subreddit_name)
                logger.info(f"Fetching from r/{subreddit_name}")

                for keyword_query in keywords:
                    # Search posts in subreddit
                    posts = subreddit.search(keyword_query, sort='new', time_filter='week', limit=20)
                    
                    for post in posts:
                        all_posts.append({
                            'id': post.id,
                            'text': f"{post.title} {(post.selftext or '')[:200]}",  # Title + truncated body (like tweet)
                            'created_at': datetime.fromtimestamp(post.created_utc),
                            'public_metrics': post.score,  # Upvotes
                            'geo': None,
                            'keyword': keyword_query,
                            'subreddit': subreddit_name,
                            'url': post.url,
                            'num_comments': post.num_comments
                        })
            except praw.exceptions.NotFound:
                logger.warning(f"r/{subreddit_name} not found, skipping")
                continue
            except Exception as e:
                logger.warning(f"Error in r/{subreddit_name}: {str(e)}")
                continue

        # Deduplicate by ID
        all_posts = list({post['id']: post for post in all_posts}.values())

        # Save to CSV
        if all_posts:
            df = pd.DataFrame(all_posts)
            data_path = 'disaster_ai/data'
            os.makedirs(data_path, exist_ok=True)
            df.to_csv(os.path.join(data_path, 'posts_raw.csv'), index=False)
            logger.info(f"Saved {len(all_posts)} Reddit posts to {data_path}/posts_raw.csv")
        else:
            logger.warning("No posts fetched")

    except Exception as e:
        logger.error(f"Error fetching Reddit posts: {str(e)}")
        logger.info("Using sample data. Setup free Reddit API: https://reddit.com/prefs/apps")

if __name__ == "__main__":
    fetch_posts()
    print("Reddit post fetching complete. Check data/posts_raw.csv")

