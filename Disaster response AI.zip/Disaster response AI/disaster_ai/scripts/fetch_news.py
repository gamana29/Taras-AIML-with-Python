from newsapi import NewsApiClient
import pandas as pd
from dotenv import load_dotenv
import os
import logging
from datetime import datetime, timedelta

load_dotenv()

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def fetch_news():
    """Fetch disaster news using NewsAPI"""
    try:
        api_key = os.getenv('NEWSAPI_KEY')
        
        if not api_key:
            logger.warning("NewsAPI key not found in .env. Creating sample news data.")
            create_sample_news()
            return
        
        # Initialize NewsAPI client
        newsapi = NewsApiClient(api_key=api_key)
        
        # Disaster keywords
        keywords = 'disaster OR flood OR earthquake OR wildfire OR hurricane OR tornado OR tsunami lang:en'
        
        # Fetch news from last 7 days
        from_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
        
        # Top headlines
        headlines = newsapi.get_everything(
            q=keywords,
            from_param=from_date,
            language='en',
            sort_by='publishedAt',
            page_size=100
        )
        
        articles = []
        for article in headlines['articles']:
            articles.append({
                'title': article['title'],
                'description': article['description'],
                'url': article['url'],
                'publishedAt': article['publishedAt'],
                'source': article['source']['name']
            })
        
        if articles:
            df = pd.DataFrame(articles)
            os.makedirs('data', exist_ok=True)
            df.to_csv('data/news.csv', index=False)
            logger.info(f"Saved {len(articles)} news articles to data/news.csv")
        else:
            logger.warning("No news articles found")
            
    except Exception as e:
        logger.error(f"Error fetching news: {str(e)}")
        logger.info("Using sample news data. Get NewsAPI key from https://newsapi.org/")

def create_sample_news():
    """Create sample news data if API unavailable"""
    sample_data = [
        {
            'title': 'Floods devastate Midwest states',
            'description': 'Record rainfall causes widespread flooding across 5 states killing 12 people',
            'url': 'https://news.example.com/floods',
            'publishedAt': '2024-01-15T09:00:00Z',
            'source': 'CNN'
        },
        {
            'title': 'California wildfires rage out of control',
            'description': 'Over 100,000 acres burned, 20 homes destroyed in firestorm',
            'url': 'https://news.example.com/wildfires',
            'publishedAt': '2024-01-15T11:30:00Z',
            'source': 'BBC'
        }
    ]
    
    df = pd.DataFrame(sample_data)
    os.makedirs('data', exist_ok=True)
    df.to_csv('data/news.csv', index=False)
    logger.info("Sample news data created at data/news.csv")

if __name__ == "__main__":
    fetch_news()
    print("News fetching complete. Check data/news.csv")
