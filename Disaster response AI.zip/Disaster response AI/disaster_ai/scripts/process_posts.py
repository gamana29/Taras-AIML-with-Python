import pandas as pd
import re
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
import joblib
import numpy as np
from nltk.corpus import stopwords
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import logging
import os

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt', quiet=True)
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords', quiet=True)
try:
    nltk.data.find('sentiment/vader_lexicon')
except LookupError:
    nltk.download('vader_lexicon', quiet=True)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def clean_text(text):
    """Clean post text"""
    # Remove URLs, mentions, hashtags
    text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
    text = re.sub(r'@\w+|#\w+', '', text)
    text = re.sub(r'[^A-Za-z0-9\s]', '', text)
    text = text.lower().strip()
    return text

def load_sample_data_for_training():
    """Load sample disaster/non-disaster posts for model training"""
    sample_disaster = [
        "massive flooding downtown roads underwater",
        "earthquake hit 6.2 magnitude buildings shaking",
        "wildfires spreading fast evacuations ordered",
        "hurricane approaching category 3 expected",
        "tornado warning take shelter immediately",
        "flash flood warning avoid low lying areas",
        "tsunami warning issued after earthquake"
    ]
    
    sample_non_disaster = [
        "beautiful sunset nyc perfect evening",
        "great concert last night amazing",
        "finished workout feeling great",
        "lovely day beach family",
        "delicious pizza dinner tonight",
        "watching favorite show relaxing",
        "coffee break productive morning"
    ]
    
    # Create labeled dataset
    data = []
    for post in sample_disaster:
        data.append({'text': post, 'is_disaster': 1})
    for post in sample_non_disaster:
        data.append({'text': post, 'is_disaster': 0})
    
    return pd.DataFrame(data)

def train_disaster_classifier():
    """Train a simple disaster classifier"""
    logger.info("Training disaster classifier...")
    
    # Load training data
    train_df = load_sample_data_for_training()
    
    # Prepare features
    X = train_df['text'].apply(clean_text)
    y = train_df['is_disaster']
    
    # Create pipeline
    pipeline = Pipeline([
        ('tfidf', TfidfVectorizer(max_features=5000, stop_words='english')),
        ('clf', LogisticRegression(random_state=42))
    ])
    
    # Train model
    pipeline.fit(X, y)
    
    # Save model
    os.makedirs('models', exist_ok=True)
    joblib.dump(pipeline, 'models/disaster_classifier.pkl')
    logger.info("Model saved to models/disaster_classifier.pkl")
    
    return pipeline

def classify_posts(model, posts_df):
    """Classify Reddit posts using trained model"""
    logger.info("Classifying posts...")
    
    # Clean posts
    posts_df['clean_text'] = posts_df['text'].apply(clean_text)
    
    # Predict
    predictions = model.predict(posts_df['clean_text'])
    probabilities = model.predict_proba(posts_df['clean_text'])[:, 1]
    
    # Add predictions to dataframe
    posts_df['is_disaster'] = predictions
    posts_df['confidence'] = probabilities
    posts_df['location'] = 'Unknown'  # Parse from text if needed later
    
    return posts_df

def main():
    # Check for raw posts (new format)
    try:
        posts_df = pd.read_csv('data/posts_raw.csv')
        logger.info("Loaded Reddit posts")
    except FileNotFoundError:
        logger.warning("No raw posts found. Using sample posts.")
        try:
            posts_df = pd.read_csv('data/sample_posts.csv')
        except FileNotFoundError:
            posts_df = pd.read_csv('data/sample_tweets.csv')  # Backward compat

    # Train or load model
    try:
        model = joblib.load('models/disaster_classifier.pkl')
    except FileNotFoundError:
        model = train_disaster_classifier()
    
    # Classify posts
    classified_df = classify_posts(model, posts_df)
    
    # Save classified posts (keep name for app compatibility)
    os.makedirs('data', exist_ok=True)
    classified_df.to_csv('data/tweets_classified.csv', index=False)
    
    logger.info(f"Classification complete! {len(classified_df[classified_df['is_disaster'] == 1])} disaster posts detected.")
    print("\nTop Disaster Posts:")
    print(classified_df[classified_df['is_disaster'] == 1][['text', 'confidence']].head())

if __name__ == "__main__":
    main()

